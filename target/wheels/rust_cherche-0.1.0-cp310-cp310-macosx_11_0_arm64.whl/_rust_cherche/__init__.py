from ._rust_cherche import *

__doc__ = _rust_cherche.__doc__
if hasattr(_rust_cherche, "__all__"):
    __all__ = _rust_cherche.__all__